import os
import numpy as np
import imageio as im
from matplotlib import pyplot as plt

A = np.load('q3-input.npy')
sorted_data = np.sort((A.flatten()))
np.save('q3-output-sorted', sorted_data)

color_bar_image = np.tile(sorted_data,(300,1))

plt.figure()
plt.title('Sorted Intensities from np.random.randint')
plt.imshow(color_bar_image, cmap='gray', interpolation = 'none')

plt.figure()
plt.hist(sorted_data, bins = 20)
plt.title('Histogram of Sorted Intensities')
plt.show()

X = A[50:100, 0:50]
np.save('q3-output-x', X)
plt.figure()
plt.title('Image X')
plt.imshow(X, interpolation = 'none')

Y = A - np.mean(A)
np.save('q3-output-y', Y)
plt.figure()
plt.title('Image Y')
plt.imshow(Y, interpolation = 'none')

Z = np.zeros((100,100,3))
Z[np.where(A > np.mean(A))] = np.array([1.0,0.0,0.0])
im.imsave('q3-output-z.png', Z)
plt.figure()
plt.title('Image Z')
plt.imshow(Z, interpolation = 'none')
