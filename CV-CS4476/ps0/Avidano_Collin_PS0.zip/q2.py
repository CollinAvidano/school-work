import numpy as np

def random_dice(N):
   return ((np.random.rand(N) * 6) + 1).astype(int)

def reshape_vector(y):
  return y.reshape((3,2))

def max_value(z):
  mx = np.max(z)
  return np.where(z == mx)

def count_ones(v):
  return len(v[v == 1])
